package com.cs.model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="employee_tab")
public class Emp {

@Id
@GeneratedValue
int id;
String emp_name;
String emnum;
String addr;
String cnum;
String location;
String designation;
String email;

public String getEmp_name() {
	return emp_name;
}
public void setEmp_name(String emp_name) {
	this.emp_name = emp_name;
}
public String getEmnum() {
	return emnum;
}
public void setEmnum(String emnum) {
	this.emnum = emnum;
}
public String getAddr() {
	return addr;
}
public void setAddr(String addr) {
	this.addr = addr;
}
public String getCnum() {
	return cnum;
}
public void setCnum(String cnum) {
	this.cnum = cnum;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}





}