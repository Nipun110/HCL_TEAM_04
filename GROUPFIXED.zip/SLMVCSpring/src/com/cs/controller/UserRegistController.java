package com.cs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cs.dao.StudentDAO;
import com.cs.dao.UserRegDAO;
import com.cs.model.Student;
import com.cs.model.UserRegister;

@Controller
public class UserRegistController {
	@Autowired
	UserRegDAO  dao;
	
	/*
	 * @RequestMapping("open2") String test2() {
	 * 
	 * 
	 * return "StudentRegForm"; }
	 */


	@RequestMapping(value="userRegister",method=RequestMethod.POST)
	ModelAndView saveStudent(@ModelAttribute UserRegister u) {
		ModelAndView mv=new ModelAndView();

		if(dao.addUser(u)>0) {

			//mv.addObject("stukey", stu);


			mv.setViewName("index");
		}
		return mv;




	}
	
	
	

	@RequestMapping(value="login2",method=RequestMethod.POST)
	ModelAndView authenticate(@RequestParam String email,@RequestParam String pwd) {
		String name=dao.checkcredential( email,pwd);
		if(name!=null)
		{
			return new ModelAndView("indexlog","namekey",name);
			}

		else
			return new ModelAndView("index");
	}
	
	
	
	
	
	
	


	public UserRegDAO getDao() {
		return dao;
	}


	public void setDao(UserRegDAO dao) {
		this.dao = dao;
	}
	
	
	


}
