package com.cs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cs.dao.StudentDAO;
import com.cs.dao.UserRegDAO;
import com.cs.model.Student;
import com.cs.model.UserRegister;

@Controller
public class StudentController {
	@Autowired
	StudentDAO  dao;
	
	/*
	 * @RequestMapping("open") String test() {
	 * 
	 * 
	 * return "StudentRegForm"; }
	 */

	@RequestMapping(value="save",method=RequestMethod.POST)
	ModelAndView saveStudent(@ModelAttribute Student stu) {
		ModelAndView mv=new ModelAndView();

		if(dao.addStudent(stu)>0) {

			//mv.addObject("stukey", stu);


			mv.setViewName("Login");
		}
		return mv;




	}
	
	
	

	@RequestMapping(value="login",method=RequestMethod.POST)
	ModelAndView authenticate(@RequestParam int id,@RequestParam String pwd) {
		String name=dao.checkcredential(id, pwd);
		if(name!=null)
		{
			return new ModelAndView("Home","namekey",name);
			}

		else
			return new ModelAndView("Login","error","Please enter valid id or password");
	}
	
	
	
	
	
	
	


	public StudentDAO getDao() {
		return dao;
	}


	public void setDao(StudentDAO dao) {
		this.dao = dao;
	}
	
	
	


}
