package com.cs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cs.dao.EmploginDAO;
import com.cs.model.Emp;

@Controller
public class EmploginController {

	@Autowired
	EmploginDAO emdao;

	
	  @RequestMapping("employee") String testEmplog() { return "EmployeeReg"; }
	 

	@RequestMapping(value = "employeeSave", method = RequestMethod.POST)
	ModelAndView saveEmp(@ModelAttribute Emp em) {

		ModelAndView mv=new ModelAndView();

		if(emdao.addEmp(em)>0) {
			mv.setViewName("indexlog");
		}
		return mv;

	}

	public EmploginDAO getDao() {
		return emdao;
	}

	public void setDao(EmploginDAO emdao) {
		this.emdao = emdao;
	}

}