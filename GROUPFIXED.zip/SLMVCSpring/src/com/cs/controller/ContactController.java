package com.cs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cs.dao.ContactDAO;
import com.cs.model.Contact;



@Controller
public class ContactController {
	
	@Autowired
	ContactDAO  contactdao;
	/*
	 * @RequestMapping("open") String test() { return "Contact"; }
	 */


	@RequestMapping(value="contactSave",method=RequestMethod.POST)
	ModelAndView saveContact(@ModelAttribute Contact cnt) {
		ModelAndView mv=new ModelAndView();

		if(contactdao.addContact(cnt)>0) {
			mv.setViewName("Contact");
		}
		return mv;
	}


	

	public ContactDAO getDao() {
		return contactdao;
	}

	public void setDao(ContactDAO contactdao) {
		this.contactdao = contactdao;
	}


}
