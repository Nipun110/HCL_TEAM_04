package com.cs.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cs.model.Contact;
import com.cs.model.Student;


	
	@Repository
	public class ContactDAO {
		@Autowired
		SessionFactory factory;
		@Transactional
		public int addContact(Contact contact) {

			Session session=factory.openSession();
			int res=(int) session.save(contact);
			Transaction transactional=session.beginTransaction();
			transactional.commit();
			return res;
		}


		public Contact getContact(String name)
		{
			Session session=factory.openSession();
			return (Contact) session.get(Contact.class, name);
		}

	
		public List<Contact> getAllContact()
		{
			Session session=factory.openSession();
			Query query=session.createQuery("from Contact");
			return query.list(); 

		}


	}
