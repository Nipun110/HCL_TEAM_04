package com.cs.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cs.model.Contact;
import com.cs.model.Emp;



@Repository
public class EmploginDAO {

	@Autowired
	SessionFactory factory;

	@Transactional
	public int addEmp(Emp em) {

		Session session = factory.openSession();
		int res = (int) session.save(em);
		Transaction transactional = session.beginTransaction();
		transactional.commit();
		return res;
	}

	public Emp getEmp(String name) {
		Session session = factory.openSession();
		return (Emp) session.get(Emp.class, name);
	}

	public List<Contact>  getAllContact() {
		Session session = factory.openSession();
		Query query = session.createQuery("from Employee");
		return  query.list();

	}

}
