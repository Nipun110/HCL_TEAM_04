package com.cs.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cs.model.Student;

@Repository

public class StudentDAO {

	@Autowired
	SessionFactory factory;
	@Transactional
	public int addStudent(Student student) {

		Session session=factory.openSession();
		int res=(int) session.save(student);
		Transaction transactional=session.beginTransaction();
		transactional.commit();
		return res;

	}


	public Student getStudent(int id)
	{
		Session session=factory.openSession();
		return (Student) session.get(Student.class, id);



	}

	public String checkcredential(int id,String password)
	{
		Session session=factory.openSession();

		Query query=session.createQuery("select sname from  Student where id=:id and password=:password");
		query.setParameter("id", id);
		query.setParameter("password", password);

		String res=(String) query.uniqueResult();
		System.out.println("res "+res);
		return res;
	}

	public List<Student> getAllStudent()
	{
		Session session=factory.openSession();
		Query query=session.createQuery("from Student");

		return query.list(); 

	}


}
