package com.cs.dao;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.cs.model.UserRegister;

@Repository
public class UserRegDAO {

	
	@Autowired
	SessionFactory factory;
	@Transactional
	public int addUser(UserRegister user) {

		Session session=factory.openSession();
		int res=(int) session.save(user);
		Transaction transactional=session.beginTransaction();
		transactional.commit();
		return res;

	}
	
	public String checkcredential(String email,String password)
	{
		Session session=factory.openSession();

		Query query=session.createQuery("select userName from  UserRegister where  password=:password and email=:email");
		
		query.setParameter("password", password);
		query.setParameter("email", email);

		String res=(String) query.uniqueResult();
		System.out.println("res "+res);
		return res;
	}
}
